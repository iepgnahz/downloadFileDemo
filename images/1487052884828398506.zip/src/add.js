function add(a, b) {
    // TODO
    return a + b;
}

module.exports = add;