#!/bin/sh
ls